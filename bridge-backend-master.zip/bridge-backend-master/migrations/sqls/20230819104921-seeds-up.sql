insert into users(name, email, mobile, role_id, level, status, password, designation, bio, school, created_at, created_by)
VALUES ('Prof. Aloka Pathirana', 'aloka@gmail.com', '+4400000001', 3, 3001, 1, '$2y$10$KYjyYYCRAj0qhHPUNaKAUesMooLYDkFBofPCqAAIpioWwf6.EIK0m',
        'Consultant', '', '', CURRENT_TIMESTAMP, 0),
       ('Dr. Anuruddha', 'anuruddha@gmail.com', '+4400000002', 3, 3001, 1, '$2y$10$KYjyYYCRAj0qhHPUNaKAUesMooLYDkFBofPCqAAIpioWwf6.EIK0m',
        'Consultant',
        'MBBS, Ph.D., Fellow,
International College of Surgeons.

Ex- Professor & Head of Department
Department of Neurosurgery
Medical Faculty, UOC',
        '', CURRENT_TIMESTAMP, 0),
       ('Sandy Lockheart', 'sandy@gmail.com', '+4400000003', 4, 4001, 0, '$2y$10$KYjyYYCRAj0qhHPUNaKAUesMooLYDkFBofPCqAAIpioWwf6.EIK0m',
        'Demonologist in Asiri Hospital',
        'MBBS, Ph.D., Fellow,
International College of Surgeons.

Ex- Professor & Head of Department
Department of Neurosurgery
Medical Faculty, UOC',
        'GH School of Health', CURRENT_TIMESTAMP, 0);
