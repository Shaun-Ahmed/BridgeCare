drop trigger if exists update_last_message on messages;
drop function if exists update_last_message();
