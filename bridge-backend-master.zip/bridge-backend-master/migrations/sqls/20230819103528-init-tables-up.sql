create table if not exists users
(
    id                      bigserial
        constraint users_pk
            primary key,
    name                    varchar(255)                             not null,
    email                   varchar(255) unique                      not null,
    mobile                  varchar(50) unique                       null,
    role_id                 integer                                  not null,
    level                   integer                                  not null,
    worker_type             integer                                  null,
    status                  smallint       default 0                 not null,
    password                varchar(255)                             not null,
    designation             varchar(255)                             null,
    years_of_experience     varchar(50)                              null,
    address                 varchar(255)                             null,
    city                    varchar(100)                             null,
    postcode                varchar(50)                              null,
    bio                     text                                     null,
    interest                text                                     null,
    why                     text                                     null,
    rating                  decimal(8, 1)  default 0.0               null,
    profile_image           varchar(255)                             null,
    stripe_customer_id      varchar(255)   default null              null,
    stripe_account_id       varchar(255)   default null              null,
    school                  varchar(255)   default null              null,
    dob                     date           default null              null,
    otp                     varchar(50)    default null              null,
    reset_password_hash     varchar(255)   default null              null,
    is_verified             smallint       default 0                 not null,
    verify_account_hash     varchar(255)   default null              null,
    is_notification_enabled smallint       default 1                 not null,
    fcm_token               varchar(255)   default null              null,
    let                     decimal(12, 8) default null              null,
    lng                     decimal(12, 8) default null              null,
    rate                    decimal(50, 2) default 0.0               null,
    schedule                jsonb          default null              null,
    created_at              timestamp      default CURRENT_TIMESTAMP not null,
    created_by              bigint         default 0,
    verified_at             timestamp      default null,
    last_login_at           timestamp      default null,
    updated_at              timestamp(0),
    deleted_at              timestamp(0),
    deleted_by              bigint
);

create unique index if not exists users_id_uindex
    on users (id);


-- ----------------------------------------------------------------------------------------------------
CREATE table if not exists facilities
(
    id          bigserial
        constraint facilities_pk
            primary key,
    manager_id  bigint                              not null,
    title       varchar(255)                        not null,
    phone       varchar(255)                        not null,
    web_url     varchar(255)                        not null,
    address     text                                not null,
    city        varchar(100)                        not null,
    postcode    varchar(100)                        not null,
    about       text                                null,
    open_hours  text                                null,
    description text                                null,
    location    point                               not null,
    image       varchar(255)                        null,
    status      smallint  default 1,
    created_at  timestamp default CURRENT_TIMESTAMP not null,
    is_deleted  smallint  default 0
);

create unique index if not exists facilities_id_uindex
    on facilities (id);


-- ----------------------------------------------------------------------------------------------------
CREATE table if not exists roles
(
    id     bigserial
        constraint roles_pk
            primary key,
    title  varchar(255) not null,
    status smallint default 1
);

create unique index if not exists roles_id_uindex
    on roles (id);

insert into roles(id, title, status)
values (1, 'Superadmin', 1),
       (2, 'Admin', 1),
       (3, 'Manager', 1),
       (4, 'Worker', 1);


-- ----------------------------------------------------------------------------------------------------
CREATE table if not exists worker_types
(
    id     bigserial
        constraint worker_types_pk
            primary key,
    title  varchar(255) not null,
    status smallint default 1
);

create unique index if not exists worker_types_id_uindex
    on worker_types (id);

insert into worker_types(id, title, status)
values (1, 'Healthcare Worker', 1),
       (2, 'Physical Therapist or Fitness Instructor', 1),
       (3, 'Volunteer', 1);


-- ----------------------------------------------------------------------------------------------------
CREATE table if not exists notifications
(
    id      bigserial
        constraint notifications_pk
            primary key,
    title   varchar(255)       not null,
    message varchar(4000)      not null,
    user_id bigint             not null,
    type    smallint default 0 null,
    actions jsonb              null,
    status  smallint default 0
);

create unique index if not exists notifications_id_uindex
    on notifications (id);


-- ----------------------------------------------------------------------------------------------------
CREATE table if not exists contacts
(
    id                bigserial
        constraint contacts_pk
            primary key,
    owner_id          bigint                              not null,
    user_id           bigint                              not null,
    last_message      varchar(255)                        not null,
    last_message_type integer                             not null,
    last_message_time timestamp                           null,
    created_at        timestamp default CURRENT_TIMESTAMP not null
);

create unique index if not exists contacts_id_uindex
    on contacts (id);


-- ----------------------------------------------------------------------------------------------------
CREATE table if not exists errors
(
    id          bigserial
        constraint errors_pk
            primary key,
    type        int                                 not null,
    title       varchar(255)                        not null,
    description text                                null,
    status_code int                                 null,
    request     jsonb                               null,
    response    jsonb                               null,
    user_id     bigint                              null,
    created_at  timestamp default CURRENT_TIMESTAMP not null
);

create unique index if not exists errors_id_uindex
    on errors (id);


-- ----------------------------------------------------------------------------------------------------
CREATE table if not exists api_calling_logs
(
    id              bigserial
        constraint api_calling_logs_pk
            primary key,
    user_info       jsonb         null,
    endpoint        varchar(255)  not null,
    method          varchar(50)   not null,
    status_code     int           null,
    total_time      decimal(8, 6) null,
    request_headers jsonb         null,
    query_params    jsonb         null,
    params          jsonb         null,
    request_body    jsonb         null,
    error_body      jsonb         null,
    response_body   jsonb         null,
    time_stamp      timestamp default current_timestamp
);

create unique index if not exists api_calling_logs_id_uindex
    on api_calling_logs (id);


-- ----------------------------------------------------------------------------------------------------
CREATE table if not exists shifts
(
    id          bigserial
        constraint shifts_pk
            primary key,
    start_at    timestamp           not null,
    end_at      timestamp           not null,
    date        date                not null,
    start_time  time                not null,
    end_time    time                not null,
    facility_id bigint              not null,
    manager_id  bigint              not null,
    nurse_id    bigint              null,
    worker_type smallint            not null,
    title       varchar(255)        not null,
    notes       text                null,
    location    point               null,
    status      smallint  default 0 not null,
    created_at  timestamp default current_timestamp
);

create unique index if not exists shifts_id_uindex
    on shifts (id);


-- ----------------------------------------------------------------------------------------------------
CREATE table if not exists messages
(
    id          bigserial
        constraint messages_pk
            primary key,
    sender_id   bigint              not null,
    receiver_id bigint              not null,
    type        smallint            not null,
    message     text                not null,
    is_read     smallint  default 0 not null,
    status      smallint  default 1 not null,
    time_stamp  timestamp           not null,
    created_at  timestamp default current_timestamp
);

create unique index if not exists messages_id_uindex
    on messages (id);
