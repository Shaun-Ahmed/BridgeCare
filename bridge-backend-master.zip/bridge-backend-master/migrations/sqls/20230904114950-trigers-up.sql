CREATE OR REPLACE FUNCTION update_last_message() RETURNS TRIGGER AS $update_last_message$
BEGIN
    IF pg_trigger_depth() <> 1 THEN
        RETURN NEW;
    END IF;

    UPDATE contacts set last_message = NEW.message, last_message_type = NEW.type, last_message_time = NEW.time_stamp WHERE (owner_id = NEW.sender_id and user_id = NEW.receiver_id) or (user_id = NEW.sender_id and owner_id = NEW.receiver_id);

    RETURN NEW;
END;
$update_last_message$ LANGUAGE plpgsql;

CREATE TRIGGER update_last_message AFTER INSERT ON messages
    FOR EACH ROW EXECUTE PROCEDURE update_last_message();
--     FOR EACH ROW EXECUTE FUNCTION update_last_message();
