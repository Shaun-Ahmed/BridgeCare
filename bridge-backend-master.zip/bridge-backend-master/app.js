require('dotenv').config();
const express = require("express");
const cors = require("cors");
const statusMonitor = require('express-status-monitor');
const moment = require("moment");
const Joi = require("joi");
const cron = require('node-cron');

const JwtFunctions = require("./functions/jwt");
const {middleware} = require('./middleware/auth');

const postgresDb = require('./_db/database');
const Files = require('./functions/file_management');

const app = express();
const config = require('./functions/status_monitor_config');
app.use(statusMonitor(config));
app.use(middleware);
const server = require("http").createServer(app);

const socketIO = require("socket.io")
(
    server,
    {
        cors: {
            origin: '*',
            methods: ["GET", "POST"]
        },
        maxHttpBufferSize: 100000000,
        pingInterval: 2 * 1000,
        pingTimeout: 5000,
        connectTimeout: 5000,
        transports: ['websocket', 'polling'],
        allowEIO3: true,
        perMessageDeflate: false
    }
);

app.use(express.urlencoded({limit: '50mb', extended: true, parameterLimit: 5000}));
app.use(express.json({limit: '50mb'}));
app.use(express.text());
app.use(cors());
app.use('/public', express.static('./public'));

// routers
const auth = require('./routers/auth');
const users = require('./routers/users');
const facilities = require('./routers/facilities');
const shifts = require('./routers/shifts');
const messages = require('./routers/messages');
const payments = require('./routers/payments');

// endpoints
app.use("/auth", auth);
app.use("/users", users);
app.use("/facilities", facilities);
app.use("/shifts", shifts);
app.use("/messages", messages);
app.use("/payments", payments);

// cron.schedule('* * * * *', () => {
//     console.log('running a task every minute');
// });

const port = process.env.PORT || 8181;

const IO_PRE_DEFINED_EVENT_CONNECTION = "connection";
const IO_PRE_DEFINED_EVENT_DISCONNECT = "disconnect";
const IO_PRE_DEFINED_EVENT_ERROR = "error";

const EVENT_WELCOME = "welcome";
const EVENT_HELLO = "hello";

const usersList = new Map();

const socketConnectionSchema = Joi.object({
    id: Joi.number().min(1).required(),
    name: Joi.string().required(),
    level: Joi.number().required(),
    roll_number: Joi.string().allow("").required(),
    token: Joi.string().required(),
}).options({abortEarly: false, allowUnknown: true});

socketIO.use((socket, next) => {
    let handshake = socket.handshake;
    let client = handshake.query;

    const schemaValidationResult = socketConnectionSchema.validate(client);
    if (schemaValidationResult.error) {
        const errorMessage = schemaValidationResult.error.details.map(err => err.message).join(', ');

        console.error(errorMessage, client);
        next(new Error(errorMessage));
        return new Error(errorMessage);
    }

    if (client.token) {
        const user = JwtFunctions.verifyAuthToken(client.token);
        if (user) {
            next();
        } else {
            console.error("Invalid auth token", client);
            next(new Error("Invalid auth token"));
            return new Error("Invalid auth token");
        }
    } else {
        console.error("Auth token not found!", client);
        next(new Error("Auth token not found!"));
        return new Error("Auth token not found!");
    }
}).on(IO_PRE_DEFINED_EVENT_CONNECTION, async (socket) => {
    const client = socket.handshake.query;

    let currentSocketUser = await usersList.get(client.id);
    if (currentSocketUser && currentSocketUser.id) {
        console.log(`Re-Connected`, socket.id + ' ' + currentSocketUser.id + ':' + currentSocketUser.name);
        currentSocketUser.is_connected = true;
        currentSocketUser.socket_id = socket.id;
    } else {
        currentSocketUser = {
            id: client.id,
            name: client.name,
            socket_id: socket.id,
            level: client.level,
            is_connected: true,
            connected_at: moment().format('MMMM Do YYYY, h:mm:ss a'),
        };
        console.log(`Connected`, currentSocketUser.socket_id + ' ' + currentSocketUser.id + ':' + currentSocketUser.name);
    }

    console.log(`Connected`, currentSocketUser.socket_id + ' ' + currentSocketUser.id + ':' + currentSocketUser.name);

    usersList.set(client.id, currentSocketUser);

    // welcome message from server to client
    socketIO.to(socket.id).emit(EVENT_WELCOME, currentSocketUser);

    // hello
    socket.on(EVENT_HELLO, (data, callback) => {
        console.log('Hello', data);
        callback(null, 'got it');
    });

    // disconnect
    socket.on(IO_PRE_DEFINED_EVENT_DISCONNECT, async () => {
        console.error('Disconnected:', currentSocketUser.socket_id + ' ' + currentSocketUser.id + ':' + currentSocketUser.name);

        const connectedUser = usersList.get(currentSocketUser.id);
        if (connectedUser) {
            connectedUser.is_connected = false;

            if (connectedUser.level && connectedUser.level.toString() === '5001') {
                usersList.set(connectedUser.id, connectedUser);
            }
        }
    });

    // error
    socket.on(IO_PRE_DEFINED_EVENT_ERROR, (err) => {
        console.error('received error from client:', socket.id, err);
    });
});

app.get('/', (req, res) => {
    res.send({message: "Bridge API is up and running..."});
});

app.get("/restart", (req, res) => {
    res.send({message: "Server restarts in a moment."});
    process.exit(1);
});

app.use((req, res) => {
    res.status(404).json({not_found: "Page not found."});
});

server.listen(port, '0.0.0.0', async (err) => {
    if (err) {
        console.error("Unable to start server", err);
        Files.error(`Unable to start server ${err.message}`);
        Files.error(err);
        return;
    }

    try {
        await Files.init();
        postgresDb();

        console.log(`Server started at port '${port}'`);
        Files.log(`Server started at port '${port}'`);
    } catch (e) {
        console.error("Unable to start server", e);
        Files.error(`Unable to start server ${e.message}`);
        Files.error(e);
    }
});

module.exports = app;
