const {response, KEYS} = require("../functions/response");
const JwtFunctions = require("../functions/jwt");
const Files = require("../functions/file_management");

const MiddleWare = function (value) {
};

MiddleWare.authMiddleware = (req, res, next) => {
    const token = req.header(KEYS.tokenHeaderKey);
    if (!token) return res.status(401).send(response(401, "Unauthorized", "Auth token not found"));

    try {

        req.user = JwtFunctions.verifyAuthToken(token.replace('Bearer ', ''));

        if (!req.user) {
            res.status(401).send(response(401, "Unauthorized", "Invalid auth token.."));
            return;
        }

        const query = "SELECT * FROM users WHERE id = $1 and email = $2 and level = $3 LIMIT 1";

        process.pgpool.query(query,
            [req.user.id, req.user.email, req.user.level],
            (err, result) => {
                if (err) {
                    res.status(401).send(response(401, "Unauthorized", "Invalid auth token.", {error: err.message}));
                } else {
                    if (result && result.rowCount) {
                        next();
                    } else {
                        res.status(401).send(response(401, "Unauthorized", "Invalid auth token."));
                    }
                }
            });

    } catch (e) {
        console.error(e);
        res.status(401).send(response(401, "Unauthorized", "Invalid auth token"));
    }
};

MiddleWare.middleware = (req, res, next) => {
    const startTime = Date.now();
    const oldJson = res.json;
    res.json = (body) => {
        // console.log('user', req.user);
        // console.log('originalUrl', req.originalUrl);
        // console.log('method', req.method);
        // console.log('req.header', req.headers);
        // console.log('query', req.query);
        // console.log('params', req.params);
        // console.log('req.body', req.body);
        // console.log('statusCode', res.statusCode);
        // console.log('res.header', res.headers);
        // console.log('res.header', res.rawHeaders);
        // console.log('res.body', body);
        // console.log('err', err);

        const endTime = Date.now();
        const totalTime = (endTime - startTime) / 1000;

        if (process.env.ENABLE_API_CALLING_LOG === 'true') {
            process.pgpool.query("INSERT INTO api_calling_logs(user_info, endpoint, method, status_code, request_headers, query_params, params, request_body, response_body, total_time) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)",
                [req.user, req.originalUrl, req.method, res.statusCode, req.headers, req.query, req.params, req.body, body, totalTime],
                (err, result) => {
                    if (err) {
                        console.error(err);
                        Files.error(err, new Error());
                    }
                });
        }

        res.locals.body = body;
        return oldJson.call(res, body);
    };

    next();
};

module.exports = MiddleWare;
