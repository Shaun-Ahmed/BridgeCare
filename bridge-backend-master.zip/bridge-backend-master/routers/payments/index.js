const express = require("express");
const _ = require("lodash");
const Joi = require("joi");
const {authMiddleware} = require('../../middleware/auth');
const {response} = require('../../functions/response');

const router = express.Router();

router.get('/', authMiddleware, async (req, res) => {
    res.send(response(200, "ok", ""));
});

router.post('/', authMiddleware, async (req, res) => {
    res.send(response(200, "ok", ""));
});

module.exports = router;
