const express = require("express");
const _ = require("lodash");
const Joi = require("joi");
const {authMiddleware, orgAuthMiddleware} = require('../../middleware/auth');
const DBFunctions = require('../../_db/functions');
const {response} = require('../../functions/response');
const {validateSchema} = require("../../functions/utils");
const UserFunctions = require("./functions");
const {DB_KEYS} = require("../../_db/keys");
const CONSTANTS = require("../../resources/constants");
const {DEFAULT_VALUES} = require("../../functions/default_values");
const Files = require("../../functions/file_management");
const ImageUploader = require("../../functions/image_uploader");
const {checkHashedPassword, generateHash} = require("../../functions/hash");
const {generateAuthToken} = require("../../functions/jwt");
const CONSTANT = require("../../resources/constants.json");

const router = express.Router();

router.get('/', authMiddleware, async (req, res) => {
    const type = req.query.type;

    process.pgpool.query("SELECT id::int, name, email, profile_image, designation, years_of_experience, rating, mobile, school, bio FROM users where role_id = $1 order by name", [type],
        (error, results) => {
            if (error) {
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {
                res.send(response(200, "Users", "", {nurses: results.rows}));
            }
        });

});

router.get('/profile', authMiddleware, async (req, res) => {
    const userId = req.user.id;

    process.pgpool.query("SELECT id::int, name, email, mobile, role_id, worker_type, level, status, profile_image FROM users WHERE id = $1", [userId],
        (error, results) => {
            if (error) {
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {
                const userData = results.rows[0];
                if (!userData.profile_image) {
                    userData.profile_image = DEFAULT_VALUES.defaultProfileImageUrl;
                }
                res.send(response(200, "Profile", "", {profile: userData}));
            }
        });
});

router.get('/payment_info', authMiddleware, async (req, res) => {
    const userId = req.user.id;
    const roleId = req.user.role_id;

    if (roleId === CONSTANT.ROLE_ID.ROLE_MANAGER) {

    } else {

    }

    process.pgpool.query("SELECT id::int, name, email, mobile, role_id, worker_type, level, status, profile_image FROM users WHERE id = $1", [userId],
        (error, results) => {
            if (error) {
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {
                const userData = results.rows[0];
                if (!userData.profile_image) {
                    userData.profile_image = DEFAULT_VALUES.defaultProfileImageUrl;
                }
                res.send(response(200, "Profile", "", {profile: userData}));
            }
        });

});

router.get('/profile/:id', authMiddleware, async (req, res) => {
    const userId = req.params.id;

    process.pgpool.query("SELECT id::int, name, email, mobile, role_id::int, worker_type::int, level::int, status::int, profile_image, rating, rate, designation, bio, school, interest, dob, why FROM users WHERE id = $1", [userId],
        (error, results) => {
            if (error) {
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {
                const userData = results.rows[0];
                if (!userData.profile_image) {
                    userData.profile_image = DEFAULT_VALUES.defaultProfileImageUrl;
                }
                res.send(response(200, "Profile", "", {profile: userData}));
            }
        });
});

router.get('/schedule', authMiddleware, async (req, res) => {
    const userId = req.user.id;

    process.pgpool.query("SELECT id::int, name, email, schedule FROM users WHERE id = $1", [userId],
        (error, results) => {
            if (error) {
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {
                const userData = results.rows[0];
                res.send(response(200, "Answers submitted", "", {schedule: userData}));
            }
        });
});

const newUserSchema = Joi.object({
    name: Joi.string().required(),
    mobile: Joi.string().required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    role_id: Joi.number().min(3).max(4).required(),
    worker_type: Joi.number().min(0).max(3).required(),
    fcm_token: Joi.string().allow("").allow(null).optional(),
}).options({abortEarly: false});

router.post('/', async (req, res) => {
    const validationMessage = validateSchema(newUserSchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }

    const userData = req.body;

    const hashedPass = await generateHash(userData.password);

    const level = userData.role_id === CONSTANTS.ROLE_ID.ROLE_MANAGER ? CONSTANTS.LEVEL.LEVEL_MANAGER : CONSTANTS.LEVEL.LEVEL_WORKER;

    process.pgpool.query("INSERT INTO users(name, email, mobile, role_id, level, worker_type, password) VALUES ($1, $2, $3, $4, $5, $6, $7) returning id::int",
        [userData.name, userData.email, userData.mobile, userData.role_id, level, userData.worker_type, hashedPass],
        (err, result) => {
            if (err) {
                if (err.code && err.code === DB_KEYS.duplicateErrorCode) {
                    res.status(400).send(UserFunctions.responseDuplicateError(err));
                } else {
                    res.status(500).send(response(500, "Server error", "Internal server error", {error: err.message}));
                }
            } else {
                const user = userData;

                user.id = result.rows[0].id;
                user.level = level;
                user.status = 0;
                user.auth_token = generateAuthToken(user);
                userData.profile_image = DEFAULT_VALUES.defaultProfileImageUrl;

                if (userData.fcm_token && userData.fcm_token !== '') {
                    DBFunctions.query("UPDATE users SET fcm_token = $1 WHERE id = $2", [userData.fcm_token, userData.id])
                }

                // todo
                // create stripe customer account

                res.send(response(200, "User registered", "User registered", {user: _.omit(user, ['password'])}));
            }
        });
});

const scheduleSchema = Joi.object({
    monday: Joi.array().items({
        id: Joi.string().regex(/^([a-zA-Z0-9]{10})$/).required(),
        start_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
        end_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    }).min(0).required(),
    tuesday: Joi.array().items({
        id: Joi.string().regex(/^([a-zA-Z0-9]{10})$/).required(),
        start_time: Joi.string().required(),
        end_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    }).min(0).required(),
    wednesday: Joi.array().items({
        id: Joi.string().regex(/^([a-zA-Z0-9]{10})$/).required(),
        start_time: Joi.string().required(),
        end_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    }).min(0).required(),
    thursday: Joi.array().items({
        id: Joi.string().regex(/^([a-zA-Z0-9]{10})$/).required(),
        start_time: Joi.string().required(),
        end_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    }).min(0).required(),
    friday: Joi.array().items({
        id: Joi.string().regex(/^([a-zA-Z0-9]{10})$/).required(),
        start_time: Joi.string().required(),
        end_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    }).min(0).required(),
    saturday: Joi.array().items({
        id: Joi.string().regex(/^([a-zA-Z0-9]{10})$/).required(),
        start_time: Joi.string().required(),
        end_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    }).min(0).required(),
    sunday: Joi.array().items({
        id: Joi.string().regex(/^([a-zA-Z0-9]{10})$/).required(),
        start_time: Joi.string().required(),
        end_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    }).min(0).required(),
}).options({abortEarly: false});

router.post('/schedule', authMiddleware, async (req, res) => {
    const validationMessage = validateSchema(scheduleSchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }

    const schedule = req.body;

    DBFunctions.query("UPDATE users SET schedule = $1 WHERE id = $2", [schedule, req.user.id])
        .then(results => {
            res.send(response(200, "Ok", "Schedule saved"));
        })
        .catch(error => {
            console.error(error);
            Files.error(error, new Error());
            res.status(400).send(response(400, "Error", "Something went wrong please try again"));
        });

});

router.post('/profile-image', authMiddleware, (req, res) => {
    const userId = req.user.id;
    const uploader = ImageUploader.getAvatarUploader();

    uploader(req, res, (err) => {
        if (err) {
            if (err.code === 'LIMIT_FILE_SIZE') {
                console.error("File size must not be grater then 2 Mb");
                res.send(response(400, "File Size Error", "File size must not be grater then 2 Mb", {error: err}));
            } else if (err.code === 'INVALID_FORMAT') {
                console.error(err);
                res.send(response(400, "Invalid Format", err.message, {error: err}));
            } else {
                res.send(response(400, "Invalid CSV File", "Selected Image is not valid", {error: err}));
            }
        } else {
            const file = req.file;

            if (file) {
                const imagePath = `${process.env.APP_BASE_URL}/${file.path}`;
                DBFunctions.query("UPDATE users SET profile_image = $1 WHERE id = $2", [imagePath, userId]);

                res.send(response(200, "Profile image updated", "", {profile_image: imagePath}));
            } else {
                res.status(500).send(response(500, "Internal Server Error", "Unable to upload the profile image"));
            }
        }
    });
});

const changePasswordSchema = Joi.object({
    old_password: Joi.string().min(6).required(),
    new_password: Joi.string().min(6).required(),
}).options({abortEarly: false});

router.post('/change-password', authMiddleware, (req, res) => {
    const validationMessage = validateSchema(changePasswordSchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }
    const userId = req.user.id;

    DBFunctions.query("SELECT id, password FROM users WHERE id = $1", [userId])
        .then(usrData => {
            if (usrData && usrData.rows && usrData.rows.length) {
                const dbPassword = usrData.rows[0].password;
                const oldPassword = req.body.old_password;
                const newPassword = req.body.new_password;

                checkHashedPassword(oldPassword, dbPassword)
                    .then(async matched => {
                        if (matched) {
                            const hashedPass = await generateHash(newPassword);

                            DBFunctions.query("UPDATE users SET password = $1 WHERE id = $2", [hashedPass, userId])
                                .then(pc => {
                                    res.send(response(200, "Password changed", ""));
                                })
                                .catch(pcErr => {
                                    console.error(pcErr);
                                    Files.error(pcErr, new Error());
                                    res.status(500).send(response(500, "Server Error", pcErr.message));
                                });
                        } else {
                            res.status(400).send(response(400, "Invalid old password", "Invalid old password"));
                        }

                    })
                    .catch(matchedErr => {
                        console.error(matchedErr);
                        Files.error(matchedErr, new Error());
                        res.status(500).send(response(500, "Server Error", matchedErr.message));
                    });

            } else {
                res.status(404).send(response(404, "Not found", "User details not found"));
            }
        })
        .catch(usrErr => {
            console.error(usrErr);
            Files.error(usrErr, new Error());
            res.status(500).send(response(500, "Server error", "Unable to get the user details"));
        });
});

const updateProfileSchema = Joi.object({
    name: Joi.string().required(),
    experience: Joi.string().allow("").optional(),
    mobile: Joi.string().required(),
    designation: Joi.string().allow("").required(),
    address: Joi.string().required(),
    city: Joi.string().required(),
    postcode: Joi.string().allow("").optional(),
    bio: Joi.string().required(),

    school: Joi.string().allow("").allow(null).optional(),
    dob: Joi.string().allow("").allow(null).optional(),
    interest: Joi.string().allow("").allow(null).optional(),
    why: Joi.string().allow("").allow(null).optional(),
}).options({abortEarly: false});

router.post('/profile', [authMiddleware, ImageUploader.getAvatarUploader()], (req, res) => {
    const validationMessage = validateSchema(updateProfileSchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }
    const userId = req.user.id;
    const profileData = req.body;

    let profileImagePath = "";
    if (req.file) {
        profileImagePath = `${process.env.APP_BASE_URL}/${req.file.path}`;
    }

    let query;
    let values;
    if (profileImagePath) {
        query = "UPDATE users SET name = $1, years_of_experience = $2, mobile = $3, designation = $4, address = $5, city = $6, postcode = $7, bio = $8, profile_image = $9, school = $10, dob = $11, interest = $12, why = $13, status = 1 WHERE id = $14";
        values = [profileData.name, profileData.experience, profileData.mobile, profileData.designation, profileData.address, profileData.city, profileData.postcode, profileData.bio, profileImagePath, profileData.school, profileData.dob, profileData.interest, profileData.why, userId];
    } else {
        query = "UPDATE users SET name = $1, years_of_experience = $2, mobile = $3, designation = $4, address = $5, city = $6, postcode = $7, bio = $8, school = $9, dob = $10, interest = $11, why = $12, status = 1 WHERE id = $13";
        values = [profileData.name, profileData.experience, profileData.mobile, profileData.designation, profileData.address, profileData.city, profileData.postcode, profileData.bio, profileData.school, profileData.dob, profileData.interest, profileData.why, userId];
    }

    DBFunctions.query(query, values)
        .then(proData => {
            res.send(response(200, "Profile updated", "", {profile: {...profileData, profile_image: profileImagePath, status: 1}}));
        })
        .catch(proErr => {
            console.error(proErr);
            Files.error(proErr, new Error());
            res.status(500).send(response(500, "Server error", "Unable to save profile"));
        });
});

const rateSchema = Joi.object({
    rate: Joi.number().min(0.0).required(),
}).options({abortEarly: false});

router.post('/rate', authMiddleware, (req, res) => {
    const validationMessage = validateSchema(rateSchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }

    const userId = req.user.id;
    const rate = req.body.rate;

    DBFunctions.query("UPDATE users SET rate = $1 WHERE id = $2", [rate, userId])
        .then(result => {
            res.send(response(200, "ok", ""));
        })
        .catch(error => {
            console.error(error);
            Files.error(error, new Error());
            res.status(400).send(response(400, "Error", error.message));
        });

});

router.put('/notification/:value', authMiddleware, (req, res) => {
    const userId = req.user.id;
    const value = req.params.value;

    DBFunctions.query("UPDATE users SET is_notification_enabled = $1 WHERE id = $2", [value, userId])
        .then(result => {
            res.send(response(200, "ok", ""));
        })
        .catch(error => {
            console.error(error);
            Files.error(error, new Error());
            res.status(400).send(response(400, "Error", error.message));
        });

});

module.exports = router;
