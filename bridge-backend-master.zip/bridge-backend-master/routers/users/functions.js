const {response} = require("../../functions/response");

const UserFunctions = function (values) {
};

UserFunctions.responseDuplicateError = (error) => {
    if (error.constraint === 'users_email_key') {
        return response(400, "Invalid data", "Email already exists.");
    } else if (error.constraint === 'users_username_key') {
        return response(400, "Invalid data", "Username already exists.");
    } else if (error.constraint === 'users_mobile_key') {
        return response(400, "Invalid data", "Mobile number already exists.");
    } else {
        return response(400, "Invalid data", "Duplicate data", {error: error});
    }
};

UserFunctions.getById = (id) => {
    return new Promise((resolve, reject) => {
        process.pgpool.query("SELECT * FROM users WHERE id = $1", [id], (err, results) => {
            if (err) {
                return reject(err);
            } else {
                return resolve(results);
            }
        });
    });
};

UserFunctions.getByEmail = (email) => {
    return new Promise((resolve, reject) => {
        process.pgpool.query("SELECT * FROM users WHERE email = $1", [email.toLowerCase()], (err, results) => {
            if (err) {
                return reject(err);
            } else {
                return resolve(results);
            }
        });
    });
};

module.exports = UserFunctions;
