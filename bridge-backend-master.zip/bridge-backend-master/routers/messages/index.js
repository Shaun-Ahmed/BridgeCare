const express = require("express");
const _ = require("lodash");
const Joi = require("joi");
const DBFunctions = require('../../_db/functions');
const {authMiddleware} = require('../../middleware/auth');
const {response} = require('../../functions/response');
const {validateSchema} = require("../../functions/utils");
const Files = require("../../functions/file_management");
const {query} = require("express");

const router = express.Router();

router.get('/contacts', authMiddleware, async (req, res) => {

    process.pgpool.query("SELECT c.id::int, u.id::int as user_id, u.name, u.profile_image, c.last_message, c.last_message_time::text FROM contacts c JOIN users u on u.id = c.user_id WHERE c.owner_id = $1", [req.user.id],
        (error, results) => {
            if (error) {
                console.error(error);
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {
                res.send(response(200, "ok", "", {contacts: results.rows}));

                DBFunctions.query("UPDATE messages SET is_read = 1 WHERE receiver_id = $1", [req.user.id]);
            }
        });

});

router.get('/:rid', authMiddleware, async (req, res) => {
    const receiverId = req.params.rid;
    const userId = req.user.id;

    DBFunctions.query("SELECT sender_id::int, receiver_id::int, message, type::int, time_stamp::text, sender_id = $1 as send_by_me FROM messages WHERE (sender_id = $2 and receiver_id = $3) or (receiver_id = $4 and sender_id = $5) order by id desc", [userId, receiverId, userId, receiverId, userId])
        .then(data => {
            res.send(response(200, "ok", "", {messages: data.rows}));
        })
        .catch(err => {
            console.error(err);
            Files.error(err, new Error());
            res.status(400).send(response(400, "Error", "Something went wrong please try again"));
        });

});

const messageSchema = Joi.object({
    receiver_id: Joi.number().required(),
    type: Joi.number().required(),
    message: Joi.string().required(),
    timestamp: Joi.string().required(),
}).options({abortEarly: false});

router.post('/', authMiddleware, async (req, res) => {
    const validationMessage = validateSchema(messageSchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }

    const message = req.body;
    const userId = req.user.id;

    let contactsAvailable = false;
    await DBFunctions.query("SELECT * FROM contacts WHERE (owner_id = $1 and user_id = $2) or (user_id = $3 and owner_id = $4)",
        [userId, message.receiver_id, userId, message.receiver_id])
        .then(async results => {
            if (results && results.rowCount === 2) {
                contactsAvailable = true;
            } else {
                await DBFunctions.query("INSERT INTO contacts(owner_id, user_id, last_message, last_message_type, last_message_time) VALUES ($1, $2, $3, $4, $5), ($6, $7, $8, $9, $10)",
                    [userId, message.receiver_id, message.message, message.type, message.timestamp, message.receiver_id, userId, message.message, message.type, message.timestamp])
                    .then(data => {
                        console.log("contacts saved");
                    })
                    .catch(err => {
                        console.error(err);
                        Files.error(err, new Error());
                    });
            }

            DBFunctions.query("INSERT INTO messages(sender_id, receiver_id, type, message, time_stamp) VALUES ($1, $2, $3, $4, $5)",
                [userId, message.receiver_id, message.type, message.message, message.timestamp])
                .then(data => {
                    res.send(response(200, "ok", ""));
                })
                .catch(err => {
                    console.error(err);
                    Files.error(err, new Error());
                    res.status(400).send(response(400, "Error", "Something went wrong please try again"));
                });
        })
        .catch(error => {
            console.error(error);
            Files.error(error, new Error());
        });

});

module.exports = router;
