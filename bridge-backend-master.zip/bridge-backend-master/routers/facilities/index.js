const express = require("express");
const _ = require("lodash");
const Joi = require("joi");
const asyncLib = require("async");
const haversine = require("haversine-distance");
const DBFunctions = require('../../_db/functions');
const {authMiddleware} = require('../../middleware/auth');
const {response} = require('../../functions/response');
const {validateSchema} = require("../../functions/utils");
const Files = require('../../functions/file_management');
const ImageUploader = require("../../functions/image_uploader");
const CONSTANT = require("../../resources/constants.json");

const router = express.Router();

// function toFixed(x) {
//     if (Math.abs(x) < 1.0) {
//         var e = parseInt(x.toString().split('e-')[1]);
//         if (e) {
//             x *= Math.pow(10, e - 1);
//             x = '0.' + (new Array(e)).join('0') + x.toString().substring(2);
//         }
//     } else {
//         var e = parseInt(x.toString().split('+')[1]);
//         if (e > 20) {
//             e -= 20;
//             x /= Math.pow(10, e);
//             x += (new Array(e + 1)).join('0');
//         }
//     }
//     return x;
// }

router.get('/', authMiddleware, async (req, res) => {
    const lat = req.query.lat;
    const lng = req.query.lng

    let facilities = Array();

    process.pgpool.query("SELECT f.id::int, manager_id::int, u.name, u.designation, u.bio, u.profile_image, u.mobile, title, phone, f.address, f.city, f.postcode, about, location, image FROM facilities f JOIN users u on u.id = f.manager_id WHERE is_deleted = 0", [],
        async (error, results) => {
            if (error) {
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {

                if (lat && lng) {
                    const pointA = [lat, lng];
                    await asyncLib.forEach(results.rows, (value, cb) => {
                        // console.log("value", value);
                        const distanceInMeters = parseFloat(haversine(pointA, [value.location.x, value.location.y]).toFixed(6));

                        // console.log('distanceInMeters', distanceInMeters);
                        // console.log('distanceInMeters <= 5', distanceInMeters <= 5.0);
                        if (distanceInMeters <= 5000.0) {
                            facilities.push({...value, distance: distanceInMeters});
                        }

                        cb();
                    });
                } else {
                    facilities = results.rows;
                }

                res.send(response(200, "ok", "", {facilities: facilities}));

            }
        });

});

router.get('/open_shifts', authMiddleware, async (req, res) => {
    const lat = req.query.lat;
    const lng = req.query.lng;
    const date = req.query.date;

    let facilities = Array();

    let query;
    let values;
    if (date) {
        query = "select f.id::int, f.manager_id::int, u.name, u.designation, u.bio, u.profile_image, u.mobile, f.title, phone, f.address, f.city, f.postcode, about, f.location, image, s.id::int as shift_id, s.start_at::text, s.end_at::text from shifts s join facilities f on s.facility_id = f.id join users u on u.id = f.manager_id where s.start_at = $1 and s.nurse_id is null";
        values = [date];
    } else {
        query = "select f.id::int, f.manager_id::int, u.name, u.designation, u.bio, u.profile_image, u.mobile, f.title, phone, f.address, f.city, f.postcode, about, f.location, image, s.id::int as shift_id, s.start_at::text, s.end_at::text from shifts s join facilities f on s.facility_id = f.id join users u on u.id = f.manager_id where s.nurse_id is null";
        values = [];
    }

    process.pgpool.query(query, values,
        async (error, results) => {
            if (error) {
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {

                if (lat && lng) {
                    const pointA = [lat, lng];
                    await asyncLib.forEach(results.rows, (value, cb) => {
                        // console.log("value", value);
                        const distanceInMeters = parseFloat(haversine(pointA, [value.location.x, value.location.y]).toFixed(6));

                        // console.log('distanceInMeters', distanceInMeters);
                        // console.log('distanceInMeters <= 5', distanceInMeters <= 5.0);
                        if (distanceInMeters <= 5000.0) {
                            facilities.push({...value, distance: distanceInMeters});
                        }

                        cb();
                    });
                } else {
                    facilities = results.rows;
                }

                res.send(response(200, "ok", "", {facilities: facilities}));

            }
        });

});

router.get('/:id', authMiddleware, (req, res) => {
    const id = req.params.id;

    process.pgpool.query("SELECT f.id::int, manager_id::int, u.name, u.designation, u.profile_image, u.mobile, title, phone, f.address, f.city, f.postcode, about, location, image, web_url, open_hours FROM facilities f JOIN users u on u.id = f.manager_id WHERE is_deleted = 0 and f.id = $1", [id],
        async (error, results) => {
            if (error) {
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {
                let shifts = [];
                if (results && results.rowCount) {
                    const facility = results.rows[0];

                    DBFunctions.query("SELECT * FROM shifts WHERE facility_id = $1 and start_at >= now()", [facility.id])
                        .then(shiftsData => {
                            shifts = shiftsData.rows;
                        })
                        .catch(shiftsError => {
                            console.error(shiftsError);
                            Files.error(shiftsError);
                        });

                }
                res.send(response(200, "ok", "", {facility: results.rows[0] ?? null, shifts: shifts}));
            }
        });
});

const facilitySchema = Joi.object({
    title: Joi.string().required(),
    web_url: Joi.string().required(),
    phone: Joi.string().required(),
    address: Joi.string().required(),
    city: Joi.string().required(),
    postcode: Joi.string().required(),
    about: Joi.string().allow(null).allow("").optional(),
    open_hours: Joi.string().allow(null).allow("").optional(),
    lat: Joi.number().allow(null).allow(0).optional(),
    lng: Joi.number().allow(null).allow(0).optional(),
}).options({abortEarly: false});

router.post('/', [authMiddleware, ImageUploader.getLogoUploader()], async (req, res) => {
    const validationMessage = validateSchema(facilitySchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }

    const facility = req.body;
    const userId = req.user.id;
    const roleId = req.user.role_id;

    if (roleId !== CONSTANT.ROLE_ID.ROLE_MANAGER) {
        res.status(503).send(response(503, "Forbidden", "You are not allowed to add facility"));
        return;
    }

    let facilityImagePath = "";
    if (req.file) {
        facilityImagePath = `${process.env.APP_BASE_URL}/${req.file.path}`;
    }

    await DBFunctions.query("SELECT * FROM facilities WHERE manager_id = $1", [userId])
        .then(results => {
            if (results && results.rows && results.rows.count) {
                const fid = results.rows[0].id;

                let query;
                let values;
                if (facilityImagePath) {
                    query = "UPDATE facilities SET title = $1, phone = $2, address = $3, city = $4, postcode = $5, about = $6, location = $7, image = $8, web_url = $9, open_hours = $10 WHERE id = $11";
                    values = [facility.title, facility.phone, facility.address, facility.city, facility.postcode, facility.about, `(` + facility.lat + `,` + facility.lng + `)`, facilityImagePath, facility.web_url, facility.open_hours, fid];
                } else {
                    query = "UPDATE facilities SET title = $1, phone = $2, address = $3, city = $4, postcode = $5, about = $6, location = $7, web_url = $8, open_hours = $9 WHERE id = $10";
                    values = [facility.title, facility.phone, facility.address, facility.city, facility.postcode, facility.about, `(` + facility.lat + `,` + facility.lng + `)`, facility.web_url, facility.open_hours, fid];
                }

                process.pgpool.query(query,
                    values,
                    (error, results) => {
                        if (error) {
                            console.error(error);
                            res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
                        } else {
                            let facility;
                            if (facilityImagePath) {
                                facility = {
                                    ...req.body,
                                    image: facilityImagePath,
                                };
                            } else {
                                facility = {
                                    ...req.body,
                                };
                            }

                            res.send(response(200, "ok", "", {facility: facility}));
                        }
                    });

            } else {

                process.pgpool.query("INSERT INTO facilities(manager_id, title, phone, address, city, postcode, about, location, image, web_url, open_hours) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) returning id",
                    [userId, facility.title, facility.phone, facility.address, facility.city, facility.postcode, facility.about, `(` + facility.lat + `,` + facility.lng + `)`, facilityImagePath, facility.web_url, facility.open_hours],
                    (error, results) => {
                        if (error) {
                            console.error(error);
                            res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
                        } else {
                            const id = results.rows[0].id;

                            const facility = {
                                id: id,
                                ...req.body,
                                image: facilityImagePath,
                            };

                            res.send(response(200, "ok", "", {facility: facility}));
                        }
                    });

            }
        })
        .catch(error => {
            console.error(error);
            Files.error(error, new Error());

            res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
        });

});

module.exports = router;
