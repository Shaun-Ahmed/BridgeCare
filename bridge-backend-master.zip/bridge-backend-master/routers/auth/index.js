const express = require("express");
const _ = require("lodash");
const Joi = require("joi");
const DBFunctions = require('../../_db/functions');
const {authMiddleware} = require('../../middleware/auth');
const {checkHashedPassword} = require('../../functions/hash');
const {generateAuthToken, verifyAuthToken} = require('../../functions/jwt');
const {response, KEYS} = require('../../functions/response');
const {validateSchema} = require('../../functions/utils');
const UserFunctions = require("../users/functions");
const {StringFunctions} = require("../../functions/string");
const SendGrid = require("../../sendgrid/sendgrid_mail");
const {DEFAULT_VALUES} = require("../../functions/default_values");
const Files = require("../../functions/file_management");
const CONSTANT = require("../../resources/constants.json");
// const ForgotPasswordEmail = require("../../email-templates/forgot-password-template");
// const WelcomeEmailToUser = require("../../email-templates/otp-user-template");

const router = express.Router();

router.get('/me', authMiddleware, async (req, res) => {

    const query = "SELECT id::int, name, email, mobile, role_id, worker_type, level, status, profile_image, designation, years_of_experience, address, city, postcode, bio, rate, schedule FROM users where id = $1";

    process.pgpool.query(query, [req.user.id],
        (err, result) => {
            if (err) {
                res.status(500).send(response(500, "Error", err.message));
            } else {
                const me = result.rows[0];

                if (!me.profile_image) {
                    me.profile_image = DEFAULT_VALUES.defaultProfileImageUrl;
                }

                res.send(response(200, "Me", "", {me: me}));
            }
        });

});

const loginSchema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    fcm_token: Joi.string().allow("").allow(null).optional(),
}).options({abortEarly: false});

router.post('/login', (req, res) => {
    const validationMessage = validateSchema(loginSchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }

    const credentials = req.body;

    process.pgpool.query("SELECT id::int, name, email, mobile, role_id, worker_type, level, status, password, profile_image, designation, years_of_experience, address, city, postcode, bio, rate, schedule FROM users WHERE email = $1 and deleted_at is null;",
        [credentials.email],
        async (err, result) => {
            if (err) {
                console.error(err);
                res.status(400).send(response(400, "Invalid Credentials", "Invalid email/password please try again.", {error: err.message}));
            } else {
                if (result && result.rows && result.rows.length) {
                    let user = result.rows[0];

                    let facilityId = 0;
                    await DBFunctions.query("SELECT id FROM facilities WHERE manager_id = $1", [user.id])
                        .then(facData => {
                            if (facData && facData.rowCount && facData.rows[0].id) {
                                facilityId = facData.rows[0].id;
                            }
                        })
                        .catch(facErr => {
                            console.error(facErr);
                            Files.error(facErr, new Error());
                        });

                    checkHashedPassword(credentials.password, user.password)
                        .then(async validAuth => {
                            if (validAuth) {

                                const authToken = generateAuthToken({...user, facility_id: facilityId});
                                user.auth_token = authToken;

                                const userData = _.omit(user, ['password']);

                                if (!userData.profile_image) {
                                    userData.profile_image = DEFAULT_VALUES.defaultProfileImageUrl;
                                }

                                let facility;
                                if (userData.role_id === CONSTANT.ROLE_ID.ROLE_MANAGER) {
                                    await DBFunctions.query("SELECT id::int, title, phone, address, city, postcode, about, location, image FROM facilities WHERE manager_id = $1 LIMIT 1", [userData.id])
                                        .then(results => {
                                            if (results && results.rows && results.rows.length) {
                                                facility = results.rows[0];
                                            }
                                        })
                                        .catch(error => {
                                            console.error(error);
                                            Files.error(error, new Error());
                                        });
                                }

                                if (credentials.fcm_token && credentials.fcm_token !== '') {
                                    DBFunctions.query("UPDATE users SET fcm_token = $1 WHERE id = $2", [credentials.fcm_token, userData.id])
                                }

                                res.header(KEYS.tokenHeaderKey, authToken).send(response(200, "Logged in", "", {user: userData, facility: facility}));
                            } else {
                                res.status(400).send(response(400, "Invalid Credentials", "Invalid email/password please try again."));
                            }
                        })
                        .catch(authErr => {
                            console.error(authErr);
                            res.status(500).send(response(500, "Server Error", authErr.message));
                        });

                } else {
                    console.error("user not found");
                    res.status(400).send(response(400, "Invalid Credentials", "Invalid email/password please try again."));
                }
            }
        });
});

router.post('/logout', authMiddleware, (req, res) => {
    const id = req.user.id;

    process.pgpool.query("UPDATE users SET fcm_token = null WHERE id = $1", [id],
        (error, results) => {
            if (error) {
                res.status(500).send(response(500, "Error", error.message));
            } else {
                res.send(response(200, "Logout", "Logout successfully"));
            }
        });

});

// const forgotPasswordSchema = Joi.object({
//     email: Joi.string().email().required(),
// }).options({abortEarly: false});
//
// router.post('/forgot-password', (req, res) => {
//     const validationMessage = validateSchema(forgotPasswordSchema, req.body);
//     if (validationMessage) {
//         res.status(400).send(validationMessage);
//         return;
//     }
//
//     const email = req.body.email;
//
//     UserFunctions.getByEmail(email)
//         .then(usrRes => {
//             if (usrRes && usrRes.rows) {
//                 const userDetails = usrRes.rows[0];
//
//                 const hash = StringFunctions.generateRandomString(36);
//                 const otp = StringFunctions.generateRandomNumber(4);
//
//                 process.pgpool.query("UPDATE users SET reset_password_hash = $1, otp = $2 WHERE email = $3", [hash, otp, email],
//                     (err, results) => {
//                         if (err) {
//                             res.status(500).send(response(500, "Error", err.message));
//                         } else {
//                             const verifyLink = `https://mysolpay.knarkzdev.co.uk/forgot-password?c=${hash}`;
//                             const template = ForgotPasswordEmail.getTemplate(`${userDetails.first_name} ${userDetails.last_name}`, verifyLink, otp);
//
//                             SendGrid.mailTo(email, "Forgot Password", template);
//
//                             res.send(response(200, "Forgot password email sent"));
//                         }
//                     });
//
//             } else {
//                 res.status(404).send(response(404, "Not found", "User not found"));
//             }
//         })
//         .catch(usrErr => {
//             console.error(usrErr);
//             res.status(500).send(response(500, "Error", usrErr.message));
//         });
//
// });

module.exports = router;
