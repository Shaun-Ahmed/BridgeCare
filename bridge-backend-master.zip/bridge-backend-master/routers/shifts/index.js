const express = require("express");
// const _ = require("lodash");
const Joi = require("joi");
const querystring = require("querystring");
const DBFunctions = require('../../_db/functions');
const {authMiddleware} = require('../../middleware/auth');
const {response} = require('../../functions/response');
const {validateSchema} = require('../../functions/utils');
const CONSTANT = require('../../resources/constants');
const Files = require("../../functions/file_management");

const router = express.Router();

const shiftSearchSchema = Joi.object({
    start_date: Joi.string().regex(/^([0-9]{4})\-([0-9]{2})\-([0-9]{2})$/).allow(null).allow('').optional(),
    start_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).allow(null).allow('').optional(),
    end_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).allow(null).allow('').optional(),
    notifications: Joi.number().allow(null).allow("").optional(),
}).options({abortEarly: false});

router.get('/', authMiddleware, async (req, res) => {
    const userId = req.user.id;
    const roleId = req.user.role_id;
    const startDate = req.query.start_date;
    const startTime = req.query.start_time;
    const endTime = req.query.end_time;
    const notifications = req.query.notifications;

    const validationMessage = validateSchema(shiftSearchSchema, req.query);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }

    let where = "";
    if (startDate && startDate !== '') {
        where = " and start_at >= '" + startDate + " 00:00:00' and start_at <= '" + startDate + " 23:59:59'";
    } else if (startTime && startTime !== '' && endTime && endTime !== '') {
        where = "s.date >= now() and s.start_time >= '" + startTime + "' and s.end_time <= '" + endTime + "'";
    }

    let query;
    if (startTime && startTime !== '' && endTime && endTime !== '') {
        query = "SELECT s.id::int, s.status, s.title, s.start_at, s.end_at, s.date, s.start_time, s.end_time, s.facility_id::int, f.title as facility_name, s.manager_id::int, u.name, u.profile_image, u.designation, u.bio, u.school, s.nurse_id::int, s.worker_type::int, s.location, s.notes, s.created_at FROM shifts s LEFT JOIN users u on u.id = s.manager_id JOIN facilities f on f.id = s.facility_id WHERE " + where;
    } else if (roleId === CONSTANT.ROLE_ID.ROLE_MANAGER) {
        query = "SELECT s.id::int, s.status, s.title, s.start_at, s.end_at, s.date, s.start_time, s.end_time, s.facility_id::int, f.title as facility_name, s.manager_id::int, s.nurse_id::int, u.name, u.profile_image, u.designation, u.bio, u.school, s.worker_type::int, s.location, s.notes, s.created_at FROM shifts s LEFT JOIN users u on u.id = s.nurse_id JOIN facilities f on f.id = s.facility_id WHERE s.manager_id = " + userId + where;
    } else {
        query = "SELECT s.id::int, s.status, s.title, s.start_at, s.end_at, s.date, s.start_time, s.end_time, s.facility_id::int, f.title as facility_name, s.manager_id::int, u.name, u.profile_image, u.designation, u.bio, u.school, s.nurse_id::int, s.worker_type::int, s.location, s.notes, s.created_at FROM shifts s LEFT JOIN users u on u.id = s.manager_id JOIN facilities f on f.id = s.facility_id WHERE s.nurse_id = " + userId + where;
    }

    let unreadMessages = 0;
    if (notifications) {
        await DBFunctions.query("SELECT count(*)::int as tm FROM messages WHERE receiver_id = $1 and is_read = 0", [userId])
            .then(countData => {
                if (countData && countData.rowCount) {
                    unreadMessages = countData.rows[0].tm;
                }
            })
            .catch(countErr => {
                console.error(countErr);
                Files.error(countErr);
            });
    }

    process.pgpool.query(query, [],
        (error, results) => {
            if (error) {
                console.error(error);
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error, query: query}));
            } else {
                res.send(response(200, "ok", "", {unread_messages: unreadMessages, shifts: results.rows}));
            }
        });

});

router.get('/ledger', authMiddleware, (req, res) => {
    process.pgpool.query("SELECT id::int, title, date, start_time, end_time FROM shifts WHERE nurse_id = $1", [req.user.id],
        (error, results) => {
            if (error) {
                console.error(error);
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error, query: query}));
            } else {
                res.send(response(200, "ok", "", {shifts: results.rows}));
            }
        });
});

const shiftSchema = Joi.object({
    start_at: Joi.string().regex(/^([0-9]{4})\-([0-9]{2})\-([0-9]{2}) ([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    end_at: Joi.string().regex(/^([0-9]{4})\-([0-9]{2})\-([0-9]{2}) ([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    date: Joi.string().regex(/^([0-9]{4})\-([0-9]{2})\-([0-9]{2})$/).required(),
    start_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    end_time: Joi.string().regex(/^([0-9]{2})\:([0-9]{2})\:([0-9]{2})$/).required(),
    worker_type: Joi.number().required(),
    title: Joi.string().required(),
    notes: Joi.string().allow("").allow(null).optional(),
    nurse_id: Joi.number().allow(null).required(),
    lat: Joi.number().allow(null).optional(),
    lng: Joi.number().allow(null).optional(),
}).options({abortEarly: false});

router.post('/', authMiddleware, async (req, res) => {
    const validationMessage = validateSchema(shiftSchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }

    const managerId = req.user.id;
    let facilityId = req.user.facility_id ?? 0;
    const shift = req.body;
    const roleId = req.user.role_id;

    if (roleId !== CONSTANT.ROLE_ID.ROLE_MANAGER) {
        res.status(503).send(response(503, "Forbidden", "You are not allowed to add facility"));
        return;
    }

    let facility;
    if (facilityId === 0) {

        await DBFunctions.query("SELECT * FROM facilities WHERE manager_id = $1", [managerId])
            .then(facData => {
                facility = facData.rows[0] ?? null;
            })
            .catch(facErr => {
                console.error(facErr);
                Files.error(facErr, new Error());
            });

        if (!facility) {
            res.status(400).send(response(400, "Facility not found", "Please add facility details first"));
            return;
        }

        facilityId = facility.id;
    }

    process.pgpool.query("INSERT INTO shifts(start_at, end_at, date, start_time, end_time, facility_id, manager_id, nurse_id, worker_type, title, notes, location) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) returning id",
        [shift.start_at, shift.end_at, shift.date, shift.start_time, shift.end_time, facilityId, managerId, shift.nurse_id, shift.worker_type, shift.title, shift.notes, shift.lat ? `(` + shift.lat + `,` + shift.lng + `)` : null],
        (error, results) => {
            if (error) {
                console.error(error);
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {
                if (results && results.rowCount) {
                    shift.id = results.rows[0].id;

                    res.send(response(200, "ok", "", {shift: shift}));
                } else {
                    res.status(400).send(response(400, "Error", "Something went wrong please try again"));
                }
            }
        });

});

const shiftBookSchema = Joi.object({
    shift_id: Joi.number().min(1).required(),
    facility_id: Joi.number().min(1).required(),
    nurse_id: Joi.number().min(1).required(),
}).options({abortEarly: false});

router.post('/book', authMiddleware, async (req, res) => {
    const validationMessage = validateSchema(shiftBookSchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }

    const shift = req.body;

    process.pgpool.query("UPDATE shifts SET nurse_id = $1, status = 1 WHERE facility_id = $2 and id = $3",
        [shift.nurse_id, shift.facility_id, shift.shift_id],
        (error, results) => {
            if (error) {
                console.error(error);
                res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
            } else {
                if (results && results.rowCount) {
                    res.send(response(200, "ok", "", {shift: shift}));
                } else {
                    res.status(400).send(response(400, "Error", "Something went wrong please try again"));
                }
            }
        });

});

const shiftUpdateSchema = Joi.object({
    status: Joi.number().min(0).max(2).required(),
}).options({abortEarly: false});

router.post('/accept_reject/:id', authMiddleware, (req, res) => {
    const validationMessage = validateSchema(shiftUpdateSchema, req.body);
    if (validationMessage) {
        res.status(400).send(validationMessage);
        return;
    }

    const role = req.user.role_id;
    const shiftId = req.params.id;
    const status = req.body.status;

    let query;
    let values = [shiftId];

    if (status === 1) {
        query = "UPDATE shifts SET status = 1 WHERE id = $1"
        values = [shiftId];
    } else {
        query = "UPDATE shifts SET status = 0, nurse_id = null WHERE id = $1"
        values = [shiftId];
    }

    if (role === CONSTANT.ROLE_ID.ROLE_MANAGER) {
        process.pgpool.query("DELETE FROM shifts WHERE id = $1", [shiftId],
            (error, results) => {
                if (error) {
                    console.error(error);
                    res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
                } else {
                    res.send(response(200, "ok", ""));
                }
            });
    } else {
        process.pgpool.query(query, values,
            (error, results) => {
                if (error) {
                    console.error(error);
                    res.status(500).send(response(500, "Server error", "Internal server error", {error: error}));
                } else {
                    res.send(response(200, "ok", ""));
                }
            });
    }

});

module.exports = router;
