const Files = require('../functions/file_management');

const DBFunction = function (fun) {
};

DBFunction.query = (query, values) => {
    return new Promise((resolve, reject) => {
        process.pgpool.query(query, values, (err, result) => {
            if (err) {
                return reject(err);
            } else {
                return resolve(result);
            }
        });
    });
};

DBFunction.executeTransaction = async (callback) => {
    const client = await process.pgpool.connect();
    try {
        await client.query('BEGIN');
        try {

            await callback(null, client);

            await client.query('COMMIT');
        } catch (error) {
            await client.query('ROLLBACK');

            await callback(error, null);

            // console.error(error.stack);
            Files.error(error, new Error());
        }
    } finally {
        await client.end();
    }
};

DBFunction.error = async (type, title, description, ststus_code = null, request = null, response = null, user_id = null) => {
    return new Promise((resolve, reject) => {
        process.pgpool.query("INSERT INTO errors(type, title, description, status_code, request, response, user_id) values ($1, $2, $3, $4, $5, $6, $7) returning id",
            [type, title, description, ststus_code, request, response, user_id], (err, result) => {
                if (err) {
                    return reject(err);
                } else {
                    if (result && result.rows && result.rows[0].id) {
                        console.log("Inserted Error ID: ", result.rows[0].id);
                        return resolve({error_id: result.rows[0].id});
                    } else {
                        return reject({message: "Unable to fetch error id, returning id not found"});
                    }
                }
            });
    });
};

DBFunction.alert = async (type, title, description, for_user_id, action_required = true, action = null, is_unread = true) => {
    return new Promise((resolve, reject) => {
        process.pgpool.query("INSERT INTO alerts(type, title, description, for_user_id, action_required, action, is_unread) values ($1, $2, $3, $4, $5, $6, $7) returning id",
            [type, title, description, for_user_id, action_required, action, is_unread], (err, result) => {
                if (err) {
                    return reject(err);
                } else {
                    if (result && result.rows && result.rows[0].id) {
                        console.log("Inserted Alert ID: ", result.rows[0].id);
                        return resolve({alert_id: result.rows[0].id});
                    } else {
                        return reject({message: "Unable to fetch alert id, returning id not found"});
                    }
                }
            });
    });
};

module.exports = DBFunction;
