const DB_KEYS = {
    duplicateErrorCode: "23505"
};

module.exports = {
    DB_KEYS: DB_KEYS
}