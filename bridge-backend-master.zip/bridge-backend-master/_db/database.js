const postgresql =  require('pg');
const Files = require('../functions/file_management');

const { Pool } = postgresql;

module.exports = (callback = null) => {

    try {
        const pool = new Pool({
            user: process.env.DB_USER || 'postgres',
            database: process.env.DB_NAME || 'postgres',
            password: process.env.DB_USER_PASS || 'postgres',
            host: process.env.DB_HOST || '127.0.0.1',
            port: process.env.DB_PORT || 5432,
        });

        const connection = {
            pool,
            query: (...args) => {
                return pool.connect().then((client) => {
                    return client.query(...args).then((res) => {
                        client.release();
                        return res.rows;
                    });
                });
            },
        };

        process.pgsql = connection;
        process.pgpool = pool;

        if (callback) {
            callback(connection);
        }

        console.log(`Database connected at port: ${process.env.DB_PORT}`);
        Files.log(`Database connected at port: ${process.env.DB_PORT}`);

        return connection;

    } catch (e) {
        console.error(e.message);
        Files.error(e.message, new Error());
        return null;
    }

};
