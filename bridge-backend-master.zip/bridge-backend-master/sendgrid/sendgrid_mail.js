const sendgrid = require('@sendgrid/mail');

const sendgridAPIKey = process.env.MAIL_PASSWORD;
const fromEmail = process.env.MAIL_FROM_ADDRESS;
const fromName = process.env.MAIL_FROM_NAME;

const appName = process.env.APP_NAME;
const replyEmail = process.env.MAIL_REPLY_ADDRESS;

sendgrid.setApiKey(sendgridAPIKey);

module.exports.mailTo = (to, subject, mailBody, html = true) => {

    return new Promise((resolve, reject) => {

        let msg = {
            to: to,
            from: {
                email: fromEmail,
                name: fromName
            },
            replyTo: {
                email: replyEmail,
                name: appName
            },
            subject: subject,
        }

        if (html) {
            msg = { ...msg, html: mailBody };
        } else {
            msg = { ...msg, text: mailBody };
        }

        sendgrid.send(msg)
            .then(res => {
                console.log("Email send to " + to);
                // console.log(res);
                resolve(res);
            })
            .catch(e => {
                console.error(e);
                reject(e);
            });

    });
};