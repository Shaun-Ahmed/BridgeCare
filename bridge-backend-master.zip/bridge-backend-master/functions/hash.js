const bcrypt = require('bcryptjs');

async function generateHash(password) {
    const salt = await bcrypt.genSaltSync(16);
    return await bcrypt.hashSync(password, salt);
}

async function checkHashedPassword(userPassword, hashedPassword) {
    return await bcrypt.compareSync(userPassword, hashedPassword);
}

module.exports = {
    generateHash: generateHash,
    checkHashedPassword: checkHashedPassword
};