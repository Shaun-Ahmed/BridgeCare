const multer = require('multer');
const path = require('path');
const Files = require('../functions/file_management');

const ImageUploader = function (fun) {};

ImageUploader.getAvatarUploader = () => {

    const storage = multer.diskStorage({
        destination: (req, file, cb) => {
            cb(null, `./${Files.PROFILE_IMAGES_PATH}/`);
        },
        filename: (req, file, cb) => {
            cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
        },
    });

    return multer({
        storage: storage,
        limits: {fileSize: (2 * 1024 * 1024)},
        fileFilter: (req, file, cb) => {
            const filetypes = /jpeg|jpg|png|gif/;
            const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
            // const mimetype = filetypes.test(file.mimetype);
            if(extname){
                return cb(null, true);
            } else {
                cb("Invalid file type, file must be a valid 'jpeg, jpg, png, gif'", null);
            }
        },
    }).single('avatar');
};

ImageUploader.getLogoUploader = () => {

    const storage = multer.diskStorage({
        destination: (req, file, cb) => {
            cb(null, `./${Files.FACILITY_IMAGES_PATH}/`);
        },
        filename: (req, file, cb) => {
            cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
        },
    });

    return multer({
        storage: storage,
        limits: {fileSize: (2 * 1024 * 1024)},
        fileFilter: (req, file, cb) => {
            const filetypes = /jpeg|jpg|png|gif/;
            const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
            // const mimetype = filetypes.test(file.mimetype);
            if(extname){
                return cb(null, true);
            } else {
                cb("Invalid file type, file must be a valid 'jpeg, jpg, png, gif'", null);
            }
        },
    }).single('avatar');
};

module.exports = ImageUploader;
