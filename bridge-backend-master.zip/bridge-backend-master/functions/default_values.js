function getHostUrl() {
    // const isLocalhost = () => {
    //     const host = process.env.APP_BASE_URL;
    //     return host.includes('127.0.0.1') || host.includes('localhost');
    // };
    //
    // if (isLocalhost()) {
    //     return `${process.env.APP_BASE_URL}:${process.env.APP_PORT}`
    // }
    return process.env.APP_BASE_URL;
}

const DEFAULT_VALUES = {
    defaultProfileImagePath: "/public/profile_images/default_profile_image.png",
    defaultProfileImageUrl: getHostUrl() + "/public/profile_images/default_profile_image.png"
};

module.exports = {
    DEFAULT_VALUES: DEFAULT_VALUES
}
