const numeral = require('numeral');

const Numbers = function (functions) {
};

function format_decimal(number) {
    return Number.parseFloat(numeral(number).format('0.00'));
}

function user_int(number) {
    return numeral(number).format('0,0');
}

function user_decimal(number) {
    return numeral(number).format('0,0.00');
}

Numbers.formatDecimal = (number) => {
    return format_decimal(number);
};

Numbers.formatUserInteger = (number) => {
    return user_int(number);
};

Numbers.formatUserDecimal = (number) => {
    return user_decimal(number);
};

module.exports = Numbers;