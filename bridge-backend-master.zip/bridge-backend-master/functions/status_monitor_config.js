module.exports = {
    title: "mySolPay API Stats",
    spans: [
        {
            interval: 3,
            retention: 60,
        }
    ],
    chartVisibility: {
        cpu: true,
        mem: true,
        load: true,
        eventLoop: false,
        heap: true,
        responseTime: true,
        rps: true,
        statusCodes: true
    },
    healthChecks: [
        {
            protocol: 'https',
            host: 'mysolpayapi.knarkzdev.co.uk',
            path: '/',
        }
    ]
};
