const {response} = require("./response");

const UtilFunctions = function (values) {
};

UtilFunctions.validateSchema = (schema, data) => {
    const schemaValidationResult = schema.validate(data);
    if (schemaValidationResult.error) {
        return response(400, "Invalid Request", schemaValidationResult.error.details.map(err => err.message).join(', '));
    }
    return null;
};

module.exports = UtilFunctions;