const _ = require("lodash");

const JsonFunctions = function (values) {
};

JsonFunctions.isValidJson = (data) => {
    try {
        JSON.parse(data);
    } catch (e) {
        return false;
    }
    return true;
};

JsonFunctions.camelize = (obj) => {
    return _.transform(obj, (acc, value, key, target) => {
        const camelKey = _.isArray(target) ? key : _.camelCase(key);

        acc[camelKey] = _.isObject(value) ? JsonFunctions.camelize(value) : value;
    });
};

JsonFunctions.snakeize = (obj) => {
    return _.transform(obj, (acc, value, key, target) => {
        const snakeKey = _.isArray(target) ? key : _.snakeCase(key);

        acc[snakeKey] = _.isObject(value) ? JsonFunctions.snakeize(value) : value;
    });
};

module.exports = JsonFunctions;