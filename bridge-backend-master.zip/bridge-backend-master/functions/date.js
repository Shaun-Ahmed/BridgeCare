const dateAndTime = require("date-and-time");

const DateFunctions = function (values) {
};

DateFunctions.USER_DATE_FORMAT_LONG = 'DD MMMM, YYYY';
DateFunctions.USER_DATE_FORMAT_SHORT = 'DD MMM';

DateFunctions.USER_DATE_FORMAT = 'DD-MM-YYYY';
DateFunctions.USER_TIME_FORMAT = 'hh:mm:ss A';
DateFunctions.USER_DATE_TIME_FORMAT = 'DD-MM-YYYY hh:mm:ss A';

DateFunctions.SQL_DATE_FORMAT = 'YYYY-MM-DD';
DateFunctions.SQL_TIME_FORMAT = 'HH:mm:ss';
DateFunctions.SQL_DATE_TIME_FORMAT = 'YYYY-MM-DD HH:mm:ss';

function getMappedDate(currentDateObj, calculatedDateObj) {
    return {
        current_date: currentDateObj,
        date: calculatedDateObj,
    };
}

DateFunctions.currentISOTimeStamp = () => new Date().toISOString();
DateFunctions.currentLocalTimeStamp = () => new Date().toLocaleString();

DateFunctions.getDate = (date, year = 0, month = 0, day = 0) => {
    const today = date || new Date();
    const dateObj = new Date(today.getFullYear() + year, today.getMonth() + month, today.getDate() + day, 0, 0, 0, 0);

    return {
        date_time: dateObj,
        current_timestamp: dateAndTime.format(today, DateFunctions.USER_DATE_TIME_FORMAT),
        current_date: dateAndTime.format(today, DateFunctions.USER_DATE_FORMAT),
        current_month: today.getMonth() + 1,
        current_day: today.getDate(),
        day_of_month: dateObj.getDate(),
        date_of_month: dateAndTime.format(dateObj, DateFunctions.USER_DATE_FORMAT),
        date_of_month_short: dateAndTime.format(dateObj, DateFunctions.USER_DATE_FORMAT_SHORT),
        date_of_month_long: dateAndTime.format(dateObj, DateFunctions.USER_DATE_FORMAT_LONG),
    };
};

DateFunctions.addDays = (date, days) => {
    const today = date || new Date();
    const dateObj = new Date(today.getFullYear(), today.getMonth(), days, 0, 0, 0, 0);

    return {
        date_time: dateObj,
        current_timestamp: dateAndTime.format(today, DateFunctions.USER_DATE_TIME_FORMAT),
        current_date: dateAndTime.format(today, DateFunctions.USER_DATE_FORMAT),
        current_month: today.getMonth() + 1,
        current_day: today.getDate(),
        day_of_month: dateObj.getDate(),
        date_of_month: dateAndTime.format(dateObj, DateFunctions.USER_DATE_FORMAT),
        date_of_month_short: dateAndTime.format(dateObj, DateFunctions.USER_DATE_FORMAT_SHORT),
        date_of_month_long: dateAndTime.format(dateObj, DateFunctions.USER_DATE_FORMAT_LONG),
    };
};

DateFunctions.subtractDays = (date, days) => {
    const today = date || new Date();
    const dateObj = new Date(today.getFullYear(), today.getMonth(), today.getDate() - days, 0, 0, 0, 0);

    return {
        date_time: dateObj,
        current_timestamp: dateAndTime.format(today, DateFunctions.USER_DATE_TIME_FORMAT),
        current_date: dateAndTime.format(today, DateFunctions.USER_DATE_FORMAT),
        current_month: today.getMonth() + 1,
        current_day: today.getDate(),
        day_of_month: dateObj.getDate(),
        date_of_month: dateAndTime.format(dateObj, DateFunctions.USER_DATE_FORMAT),
        date_of_month_short: dateAndTime.format(dateObj, DateFunctions.USER_DATE_FORMAT_SHORT),
        date_of_month_long: dateAndTime.format(dateObj, DateFunctions.USER_DATE_FORMAT_LONG),
    };
};

DateFunctions.getFirstDayOfMonth = (date) => {
    const today = date || new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1, 0, 0, 0, 0);

    return {
        date_time: firstDayOfMonth,
        current_timestamp: dateAndTime.format(today, DateFunctions.USER_DATE_TIME_FORMAT),
        current_date: dateAndTime.format(today, DateFunctions.USER_DATE_FORMAT),
        current_month: today.getMonth() + 1,
        current_day: today.getDate(),
        first_day_of_month: firstDayOfMonth.getDate(),
        first_date_of_month: dateAndTime.format(firstDayOfMonth, DateFunctions.USER_DATE_FORMAT),
        first_date_of_month_short: dateAndTime.format(firstDayOfMonth, DateFunctions.USER_DATE_FORMAT_SHORT),
        first_date_of_month_long: dateAndTime.format(firstDayOfMonth, DateFunctions.USER_DATE_FORMAT_LONG),
    };
};

DateFunctions.getLastDayOfMonth = (date) => {
    const today = date || new Date();
    const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0, 0, 0, 0, 0);

    return {
        date_time: lastDayOfMonth,
        current_timestamp: dateAndTime.format(today, DateFunctions.USER_DATE_TIME_FORMAT),
        current_date: dateAndTime.format(today, DateFunctions.USER_DATE_FORMAT),
        current_month: today.getMonth() + 1,
        current_day: today.getDate(),
        last_day_of_month: lastDayOfMonth.getDate(),
        last_date_of_month: dateAndTime.format(lastDayOfMonth, DateFunctions.USER_DATE_FORMAT),
        last_date_of_month_short: dateAndTime.format(lastDayOfMonth, DateFunctions.USER_DATE_FORMAT_SHORT),
        last_date_of_month_long: dateAndTime.format(lastDayOfMonth, DateFunctions.USER_DATE_FORMAT_LONG),
    };
};

DateFunctions.formatDate = (date, format = DateFunctions.SQL_DATE_FORMAT) => {
    return dateAndTime.format(date, format);
};

DateFunctions.getUserReadableTimeStamp = () => {
    const today = new Date();
    return dateAndTime.format(today, DateFunctions.USER_DATE_TIME_FORMAT);
};

module.exports = DateFunctions;

/*

YYYY	four-digit year	                        0999, 2015
YY	    two-digit year	                        99, 01, 15
Y	    four-digit year without zero-padding	2, 44, 888, 2015
MMMM	month name (long)	                    January, December
MMM	    month name (short)	                    Jan, Dec
MM	    month with zero-padding	                01, 12
M	    month	                                1, 12
DD	    date with zero-padding	                02, 31
D	    date	                                2, 31
dddd	day of week (long)	                    Friday, Sunday
ddd	    day of week (short)	                    Fri, Sun
dd	    day of week (very short)	            Fr, Su
HH	    24-hour with zero-padding	            23, 08
H	    24-hour	                                23, 8
hh	    12-hour with zero-padding	            11, 08
h	    12-hour	                                11, 8
A	    meridiem (uppercase)	                AM, PM
mm	    minute with zero-padding	            14, 07
m	    minute	                                14, 7
ss	    second with zero-padding	            05, 10
s	    second	                                5, 10
SSS	    millisecond (high accuracy)	            753, 022
SS	    millisecond (middle accuracy)	        75, 02
S	    millisecond (low accuracy)	            7, 0
Z	    time zone offset value	                +0100, -0800
ZZ	    time zone offset value with colon	    +01:00, -08:00

DDD	    ordinal notation of date	            1st, 2nd, 3rd
AA	    meridiem (uppercase with ellipsis)	    A.M., P.M.
a	    meridiem (lowercase)	                am, pm
aa	    meridiem (lowercase with ellipsis)	    a.m., p.m.

        replace(/T/, ' ').replace(/\..+/, '')
 */
