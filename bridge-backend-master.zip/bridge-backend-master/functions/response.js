const KEYS = {
    // tokenHeaderKey: "x-auth-token"
    tokenHeaderKey: "Authorization"
};

function response(code, message, description, data) {
    return {
        'code': code,
        'message': message,
        'description': description,
        'data': data
    };
}

module.exports = {
    response: response,
    KEYS: KEYS
}
