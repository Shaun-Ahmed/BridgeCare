const QRC = require('qrcode');
const UUID = require('uuid');
const Files = require("./file_management");

const qrCodesFolderPath = Files.QR_CODES_IMAGES_PATH;

const QRCode = function (code) {
};

QRCode.generateQRCode = data => {
    const uid = UUID.v4();
    const filePath = `${qrCodesFolderPath}/${uid}.png`;
    return new Promise((resolve, reject) => {
        QRC.toFile(filePath, data, {scale: 8, width: 512})
            .then(data => {
                return resolve({uid: uid, path: `${process.env.APP_BASE_URL}/${filePath}`});
            })
            .catch(err => {
                return reject(err);
            });
    });
};

module.exports = QRCode;
