const HmacSHA512 = require("crypto-js/hmac-sha512");
const Base64 = require("crypto-js/enc-base64");

const StringFunctions = function (formatter) {
};

const CHAR_SETS = {
    "NUMERIC": "1234567890",
    "ALPHA_NUMERIC": "AaBbC1cDdEe2FfGgH3hIiJj4KkLlM5mNnOo6PpQqR7rSsTt8UuVvW9wXxYy0Zz",
    "ALPHA_NUMERIC_UPPER_ONLY": "ABC1DE2FGH3IJ4KLM5NO6PQR7ST8UVW9XY0Z",
    "HAX": "0Aa1B7b2Cc3D8d4E9e5Ff6",
};

StringFunctions.generateRandomString = (length = 6, characters = CHAR_SETS.ALPHA_NUMERIC) => {
    let result = '';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i += 1) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
};

StringFunctions.generateRandomNumber = (length = 6, characters = CHAR_SETS.NUMERIC) => {
    let result = '';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i += 1) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
};

StringFunctions.generateRandomHaxString = (length) => {
    let result = '';
    let characters = CHAR_SETS.HAX;
    let charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
};

StringFunctions.generateRandomHaxGuid = () => {
    let first_string = StringFunctions.generateRandomHaxString(8);
    let second_string = StringFunctions.generateRandomHaxString(4);
    let third_string = StringFunctions.generateRandomHaxString(4);
    let fourth_string = StringFunctions.generateRandomHaxString(4);
    let fifth_string = StringFunctions.generateRandomHaxString(12);

    return first_string + '-' + second_string + '-' + third_string + '-' + fourth_string + '-' + fifth_string;
};

StringFunctions.generateBash64Hash = (text, secretCode) => {
    const hash = HmacSHA512(text, secretCode);
    return Base64.stringify(hash);
};

module.exports = {StringFunctions, CHAR_SETS};
