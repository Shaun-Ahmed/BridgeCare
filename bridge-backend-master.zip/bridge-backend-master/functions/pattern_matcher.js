const Pattern = function (fun) {};

Pattern.MULTI_IDS = "^([1-9][0-9]*)(\,[1-9][0-9]*)*$";  // 1,2,3
Pattern.DATE = "^\\d{4}-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])$";   // 2023-12-31
Pattern.TIME = "^([0-1][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$";   // 17:30:59
Pattern.TIME_STAMP = `${Pattern.DATE} ${Pattern.TIME}`; // 2023-12-31 17:30:59

Pattern.isMultiIds = (keys) => {
    const exp = RegExp(Pattern.MULTI_IDS);
    return exp.test(keys);
};

Pattern.isSingleId = (keys) => {
    const exp = RegExp("^[1-9][0-9]*$");
    return exp.test(keys);
};

Pattern.isNumber = (keys) => {
    const exp = RegExp("^[0-9]*$");
    return exp.test(keys);
};

Pattern.isBoolean = (keys) => {
    const exp = RegExp("^(true|false|1|0)$");
    return exp.test(keys);
};

Pattern.isBooleanTrue = (keys) => {
    const exp = RegExp("^(true|1)$");
    return exp.test(keys);
};

Pattern.isDate = (date) => {
    const exp = RegExp(Pattern.DATE);
    return exp.test(date);
};

Pattern.isTime = (time) => {
    const exp = RegExp(Pattern.TIME);
    return exp.test(time);
};

Pattern.isTimeStamp = (stamp) => {
    const exp = RegExp(Pattern.TIME_STAMP);
    return exp.test(stamp);
};

module.exports = Pattern;
