const fs = require("fs");
const moment = require("moment");

const Files = function (fun) {};

const publicDirectoryPath = './public';
const storageDirectoryPath = './storage';

const profileImagesDirectoryPath = './public/profile_images';
const facilityImagesDirectoryPath = './public/facility_images';

const activityLogsDirectoryPath = './storage/activity_logs';
const consoleLogsDirectoryPath = './storage/console_logs';

const consoleLogFilePath = './storage/console_logs/console.log';
const consoleErrorFilePath = './storage/console_logs/console.error.log';

Files.PROFILE_IMAGES_PATH = 'public/profile_images';
Files.FACILITY_IMAGES_PATH = 'public/facility_images';
Files.ACTIVITY_LOG_FOLDER = 'storage/activity_logs';

function createAllSubStorageFolders() {
    try {

        if (!fs.existsSync(facilityImagesDirectoryPath)) {
            fs.mkdirSync(facilityImagesDirectoryPath);
            console.log("storage/activity_logs directory created");
        }

        if (!fs.existsSync(activityLogsDirectoryPath)) {
            fs.mkdirSync(activityLogsDirectoryPath);
            console.log("storage/activity_logs directory created");
        }

        if (!fs.existsSync(consoleLogsDirectoryPath)) {
            fs.mkdirSync(consoleLogsDirectoryPath);
            console.log("storage/console_logs directory created");
        }

        if (!fs.existsSync(consoleLogFilePath)) {
            console.log(consoleLogFilePath + " created");
            fs.appendFile(consoleLogFilePath, moment().format('MMMM-Do-YYYY,hh:mm:ss_a') + " :: console.log file created" + '\n', function (err) {
                if (err) console.error(err);
            });
        }

        if (!fs.existsSync(consoleErrorFilePath)) {
            console.log(consoleErrorFilePath + " created");
            fs.appendFile(consoleErrorFilePath, moment().format('MMMM-Do-YYYY,hh:mm:ss_a') + " :: console.error.log file created\n", function (err) {
                if (err) console.error(err);
            });
        }

    } catch (e) {
        console.error(e);
    }
}

Files.init = async () => {
    try {

        if (!fs.existsSync(storageDirectoryPath)) {
            fs.mkdirSync(storageDirectoryPath);
            console.log("storage directory created");

            createAllSubStorageFolders();
        } else {
            createAllSubStorageFolders();
        }

    } catch (e) {
        console.error(e);
    }
}

Files.readLogFile = (path, toJson = true) => {
    return new Promise((resolve, reject) => {
        try {

            if (!fs.existsSync(`${activityLogsDirectoryPath}/${path}`)) {
                return reject({code: 404, message: "file not found"});
            }

            fs.readFile(`${activityLogsDirectoryPath}/${path}`, (err, data) => {
                if (err) {
                    console.error(err);
                    return reject({code: 500, message: err.message});
                } else {
                    if (toJson) {
                        return resolve(JSON.parse(data));
                    } else {
                        return resolve(data);
                    }
                }
            });

        } catch (e) {
            console.error(e);
            return reject({code: 500, message: e.message});
        }
    });
}

Files.saveActivityLogs = async (folderName, fileName, logs) => {
    try {

        if (!fs.existsSync(`${activityLogsDirectoryPath}/${folderName}`)) {
            await fs.mkdirSync(`${activityLogsDirectoryPath}/${folderName}`);
            console.log("storage/activity_logs directory created");
        }

        await fs.writeFileSync(`${activityLogsDirectoryPath}/${folderName}/${fileName}`, logs, err => {
            if (err) console.error(err);
            console.log("Activity logs saved");
        });

    } catch (e) {
        console.error(e);
    }
}

Files.exists = async (path) => {
    return new Promise((resolve, reject) => {
        try {
            if (fs.existsSync(path)) {
                return resolve(true);
            } else {
                return reject(false);
            }
        } catch (e) {
            console.error(e);
            return reject(false);
        }
    });
}

Files.log = (content) => {
    try {
        if (fs.existsSync(consoleLogFilePath)) {
            fs.appendFileSync(consoleLogFilePath, moment().format('MMMM-Do-YYYY,hh:mm:ss_a') + " :: " + JSON.stringify(content) + '\n', function (err) {
                if (err) console.error(err);
            });
        } else {
            console.error(consoleLogFilePath, "file not found");
        }
    } catch (e) {
        console.error(e);
    }
}

Files.error = (content, errorObj) => {
    try {
        if (fs.existsSync(consoleErrorFilePath)) {
            let error = "";
            if (errorObj) {
                const regex = /(.*):(\d+):(\d+)$/
                const match = regex.exec(errorObj.stack.split("\n")[1]);
                const where = {
                    message: errorObj.message.trim(),
                    filepath: match[0].trim(),
                };
                error = JSON.stringify(where) + " -> ";
            }
            error += JSON.stringify(content);
            fs.appendFileSync(consoleErrorFilePath, moment().format('MMMM-Do-YYYY,hh:mm:ss_a') + " :: " + error + '\n', function (err) {
                if (err) console.error(err);
            });
        } else {
            console.error(consoleErrorFilePath, "file not found");
        }
    } catch (e) {
        console.error(e);
    }
}

module.exports = Files;
