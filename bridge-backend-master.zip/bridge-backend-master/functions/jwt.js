const Jwt = require("jsonwebtoken");
const config = require("config");
const Files = require('../functions/file_management');

const JwtFunctions = function (jwt) {
};

JwtFunctions.generateAuthToken = (user) => {
    return Jwt.sign({
            id: user.id,
            role_id: user.role_id || 0,
            worker_id: user.worker_id || 0,
            facility_id: user.facility_id || 0,
            level: user.level || 0,
            name: user.name.trim(),
            email: user.email,
            mobile: user.mobile || "",
        },
        process.env.JWT_SECRET_KEY || config.get("jwt_secret_key"),
        // {
        //     expiresIn: '1h',
        // },
        null
    );
}

JwtFunctions.verifyAuthToken = token => {
    try {
        return Jwt.verify(token, process.env.JWT_SECRET_KEY || config.get("jwt_secret_key"), null, null);
    } catch (e) {
        // const error = {
        //     error: "Unable to verify token:",
        //     token: token,
        //     e: e.message
        // };
        console.error(e);
        // Files.error(error, new Error());
        return false;
    }
};

JwtFunctions.generatePaymentToken = (paymentData) => {
    return Jwt.sign({...paymentData},
        process.env.JWT_SECRET_KEY_FOR_PAYMENTS || config.get("jwt_secret_key_for_payments"),
        {
            expiresIn: '1m',
        },
        null
    );
};

JwtFunctions.verifyPaymentToken = (paymentToken) => {
    return Jwt.verify(paymentToken, process.env.JWT_SECRET_KEY_FOR_PAYMENTS || config.get("jwt_secret_key_for_payments"), null, null);
};

module.exports = JwtFunctions;
